<?php

namespace IntimateTales\User\Relationships;

use InvalidArgumentException;

class Couple
{
    public function getCouple(int $userId): ?int
    {
        if ($userId <= 0) {
            throw new InvalidArgumentException('Invalid user ID');
        }
        // Rest of the code...
    }

    public function createCouple(int $user1Id, int $user2Id): bool
    {
        if ($user1Id <= 0 || $user2Id <= 0) {
            throw new InvalidArgumentException('Invalid user IDs');
        }
        // Rest of the code...
    }

    public function breakUp(int $user1Id, int $user2Id): bool
    {
        if ($user1Id <= 0 || $user2Id <= 0) {
            throw new InvalidArgumentException('Invalid user IDs');
        }
        // Rest of the code...
    }

    public function save()
    {
        // Implement the logic to save the current state of the object in the database.
        // Throw an exception if the save operation fails.
    }
}
