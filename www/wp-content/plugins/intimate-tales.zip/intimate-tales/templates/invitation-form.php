<form action="" method="post">
    <label for="partner_username">Enter the username or email of the user you want to invite:</label>
    <input type="text" id="partner_username" name="partner_username" required>
    <input type="submit" value="Send Invitation">
</form>
