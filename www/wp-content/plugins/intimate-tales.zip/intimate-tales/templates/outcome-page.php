<!-- outcome-page.php -->

<div class="outcome-page">
    <h2>Combined Outcome</h2>
    <p><?php echo $outcome_text; ?></p>
    <!-- Display the combined outcome of the story here -->
</div>
