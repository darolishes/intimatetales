<?php
namespace IntimateTales;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Class User
 * Represents a user of the Intimate Tales plugin with additional information.
 */
class User {
    private $wp_user; // An instance of WP_User
    private $age;
    private $intimacy_level;
    private $desired_scenarios;
    private $role_playing_themes;
    private $couple_id;

    /**
     * User constructor.
     *
     * @param WP_User $wp_user An instance of WP_User representing the user.
     * @param int $intimacy_level The intimacy level of the user (non-negative integer).
     * @param string $desired_scenarios The desired scenarios for roleplaying (sanitized text).
     * @param string $role_playing_themes The role-playing themes for the user (sanitized text).
     */
    public function __construct(WP_User $wp_user, $intimacy_level, $desired_scenarios, $role_playing_themes) {
        $this->wp_user = $wp_user;
        $this->intimacy_level = absint($intimacy_level); // Ensure $intimacy_level is a non-negative integer
        $this->desired_scenarios = sanitize_text_field($desired_scenarios); // Sanitize as a text field
        $this->role_playing_themes = sanitize_text_field($role_playing_themes); // Sanitize as a text field
    }

    /**
     * Get the username of the user.
     *
     * @return string Username of the user.
     */
    public function getUsername() {
        return $this->wp_user->user_login;
    }

    /**
     * Get the email of the user.
     *
     * @return string Email of the user.
     */
    public function getEmail() {
        return $this->wp_user->user_email;
    }

    /**
     * Get the age of the user.
     *
     * @return int Age of the user.
     */
    public function getAge() {
        // Assume that you are storing user age as a user meta data
        return get_user_meta($this->wp_user->ID, 'age', true);
    }

    /**
     * Get the intimacy level of the user.
     *
     * @return int Intimacy level of the user.
     */
    public function getIntimacyLevel() {
        return $this->intimacy_level;
    }

    /**
     * Get the desired scenarios for roleplaying.
     *
     * @return string Desired scenarios for roleplaying.
     */
    public function getDesiredScenarios() {
        return $this->desired_scenarios;
    }

    /**
     * Get the role-playing themes for the user.
     *
     * @return string Role-playing themes for the user.
     */
    public function getRolePlayingThemes() {
        return $this->role_playing_themes;
    }

    /**
     * Save the user's additional information to user meta data in the database.
     */
    public function save() {
        // Save the user's additional information to user meta data in the database.
        update_user_meta($this->wp_user->ID, 'intimacy_level', $this->intimacy_level);
        update_user_meta($this->wp_user->ID, 'desired_scenarios', $this->desired_scenarios);
        update_user_meta($this->wp_user->ID, 'role_playing_themes', $this->role_playing_themes);
    }

    /**
     * Update the user's preferences.
     *
     * @param int $intimacy_level The updated intimacy level (non-negative integer).
     * @param string $desired_scenarios The updated desired scenarios for roleplaying (sanitized text).
     * @param string $role_playing_themes The updated role-playing themes (sanitized text).
     */
    public function update_preferences($intimacy_level, $desired_scenarios, $role_playing_themes) {
        $this->intimacy_level = absint($intimacy_level); // Ensure $intimacy_level is a non-negative integer
        $this->desired_scenarios = sanitize_text_field($desired_scenarios); // Sanitize as a text field
        $this->role_playing_themes = sanitize_text_field($role_playing_themes); // Sanitize as a text field

        // Update the user's preferences in user meta data in the database.
        $this->save();
    }
}
