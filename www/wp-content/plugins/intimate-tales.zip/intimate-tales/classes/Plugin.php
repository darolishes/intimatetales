<?php
namespace IntimateTales;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Class Plugin
 * Main class responsible for initializing the plugin and its functionalities.
 */
class Plugin {
    private static $instance;

    /**
     * Plugin version.
     *
     * @var string
     */
    private $version = '1.0.0';

    /**
     * Get the single instance of the class.
     *
     * @return Plugin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor to initialize the plugin.
     */
    private function __construct() {
        // Load the plugin text domain for translations.
        add_action('init', [$this, 'load_textdomain']);

        // Add hooks for custom post type and taxonomy registration.
        add_action('init', [$this, 'register_custom_post_type_taxonomy']);

        // Initialize the user and NLP models.
        User::get_instance();
        NLPModel::get_instance();

        // Add hooks for authentication, monetization, and encryption functionalities.
        add_action('init', [$this, 'initialize_authentication']);
        add_action('init', [$this, 'initialize_monetization']);
        add_action('init', [$this, 'initialize_encryption']);
    }

    /**
     * Load the plugin text domain for translations.
     */
    public function load_textdomain() {
        load_plugin_textdomain('intimate-tales', false, INTIMATE_TALES_PLUGIN_DIR . 'languages');
    }

    /**
     * Register the custom post type 'story' and the taxonomy 'story_category'.
     */
    public function register_custom_post_type_taxonomy() {
        StoryPostType::register();
        StoryCategoryTaxonomy::register();
    }

    /**
     * Initialize the authentication functionalities.
     * Implement your authentication logic here.
     */
    public function initialize_authentication() {
        // TODO: Implement authentication logic.
        // Example: Add hooks for login, logout, registration, etc.
    }

    /**
     * Initialize the monetization functionalities.
     * Implement your monetization logic here.
     */
    public function initialize_monetization() {
        // TODO: Implement monetization logic.
        // Example: Add hooks for in-app purchases, subscriptions, ads, etc.
    }

    /**
     * Initialize the encryption functionalities.
     * Implement your encryption logic here.
     */
    public function initialize_encryption() {
        // TODO: Implement encryption logic.
        // Example: Add hooks for encrypting and decrypting data.
    }
}
