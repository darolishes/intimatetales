<?php
namespace IntimateTales\Classes;

class Story {
    private $story_text;
    private $decision_points;

    /**
     * Initializes the story object with the provided text and decision points.
     *
     * @param string $story_text The text of the story.
     * @param array $decision_points The interactive decision points within the story.
     */
    public function __construct($story_text, $decision_points) {
        $this->story_text = $story_text;
        $this->decision_points = $decision_points;
    }

    /**
     * Renders the story with the interactive decision points.
     */
    public function render() {
        // Implement the logic to render the story with interactive decision points here.
        // You can create the HTML template for the story and use $this->story_text and $this->decision_points.

        // For example, you can use HTML templates or PHP code to create the interactive story.

        // Example implementation:
        // ob_start();
        // ?>
        <!-- Your HTML code for the story goes here -->
        <!-- Use PHP code to dynamically generate the decision points as interactive elements -->
        // <?php
        // $story_content = ob_get_clean();
        // echo $story_content;

        // Modify the method based on how you want to render the story with decision points.

        // For testing purposes, we'll provide a simple dummy story content with static decision points:
        ob_start();
        ?>
        <div class="story-content">
            <p><?php echo $this->story_text; ?></p>
            <div class="decision-points">
                <p>What do you want to do next?</p>
                <button class="decision-btn" data-decision="option1">Option 1</button>
                <button class="decision-btn" data-decision="option2">Option 2</button>
            </div>
        </div>
        <?php
        $story_content = ob_get_clean();
        echo $story_content;
    }

    /**
     * Handles the user's decision in the story.
     *
     * @param string $decision The user's decision.
     * @return string The outcome text based on the user's decision.
     */
    public function handle_decision($decision) {
        // Implement the logic to handle the user's decision in the story.
        // You can use the $decision parameter to determine the user's choice and modify the story outcome accordingly.

        // For example, you can use a switch statement or an associative array to map decisions to outcomes.

        // Example implementation:
        switch ($decision) {
            case 'option1':
                $outcome = 'You chose Option 1. This leads to outcome A.';
                break;
            case 'option2':
                $outcome = 'You chose Option 2. This leads to outcome B.';
                break;
            default:
                $outcome = 'Invalid decision.';
                break;
        }

        // Return the outcome text based on the user's decision.
        return $outcome;
    }
}
