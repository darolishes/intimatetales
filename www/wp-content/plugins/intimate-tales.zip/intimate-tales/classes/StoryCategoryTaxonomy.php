<?php
namespace IntimateTales;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Class Taxonomies
 * Registers the custom taxonomy 'story_category'.
 */
class StoryCategoryTaxonomy {
    /**
     * Register the custom taxonomy 'story_category'.
     */
    public static function register() {
        $labels = array(
            'name'                       => _x('Story Categories', 'taxonomy general name', 'intimate-tales'),
            'singular_name'              => _x('Story Category', 'taxonomy singular name', 'intimate-tales'),
            'search_items'               => __('Search Story Categories', 'intimate-tales'),
            'popular_items'              => __('Popular Story Categories', 'intimate-tales'),
            'all_items'                  => __('All Story Categories', 'intimate-tales'),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => __('Edit Story Category', 'intimate-tales'),
            'update_item'                => __('Update Story Category', 'intimate-tales'),
            'add_new_item'               => __('Add New Story Category', 'intimate-tales'),
            'new_item_name'              => __('New Story Category Name', 'intimate-tales'),
            'separate_items_with_commas' => __('Separate story categories with commas', 'intimate-tales'),
            'add_or_remove_items'        => __('Add or remove story categories', 'intimate-tales'),
            'choose_from_most_used'      => __('Choose from the most used story categories', 'intimate-tales'),
            'not_found'                  => __('No story categories found.', 'intimate-tales'),
            'menu_name'                  => __('Categories', 'intimate-tales'),
        );

        $args = array(
            'hierarchical'          => false,
            'labels'                => $labels,
            'public'                => true,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'show_in_nav_menus'     => true,
            'show_tagcloud'         => false,
            'rewrite'               => array('slug' => 'story_category'),
        );

        register_taxonomy('story_category', 'story', $args);
    }
}
