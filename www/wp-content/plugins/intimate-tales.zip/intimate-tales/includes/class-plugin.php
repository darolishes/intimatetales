<?php
namespace IntimateTales;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Class Plugin
 * Main plugin class responsible for initializing and handling the plugin functionality.
 */
class Plugin {
    // Singleton instance
    private static $instance;

    /**
     * Returns the singleton instance of the plugin.
     *
     * @return Plugin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the plugin.
     */
    private function __construct() {
        // Add hooks for custom post type and taxonomy registration, and load the text domain for translations.
        add_action('init', function() {
            $this->load_textdomain();
            $this->register_custom_post_type_taxonomy();
        });

        // Add hooks for other plugin features or actions.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts_and_styles']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts_and_styles']);
        add_action('admin_menu', [$this, 'add_plugin_settings_page']);
    }

    /**
     * Load the plugin text domain for translations.
     */
    private function load_textdomain() {
        load_plugin_textdomain('intimate-tales', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    /**
     * Register custom post type 'story' and custom taxonomy 'story_category'.
     */
    private function register_custom_post_type_taxonomy() {
        // Register the custom post type 'story'.
        StoryPostType::register();

        // Register the custom taxonomy 'story_category'.
        StoryCategoryTaxonomy::register();
    }

    /**
     * Enqueue frontend scripts and styles.
     */
    public function enqueue_scripts_and_styles() {
        // Enqueue your frontend scripts and styles here.
    }

    /**
     * Enqueue admin scripts and styles.
     */
    public function enqueue_admin_scripts_and_styles() {
        // Enqueue your admin scripts and styles here.
    }

    /**
     * Add a settings page for the plugin in the WordPress admin menu.
     */
    public function add_plugin_settings_page() {
        // Add your plugin settings page here.
    }

    // Other methods and properties can be defined here...
}
